# Multi-step Moral Dilemma Dataset Sample

This dataset contains structured moral dilemmas involving sequential decisions under conflicting values. It is intended to support research on moral reasoning, value conflict resolution, and cumulative choice modeling in artificial intelligence or cognitive science.

## Data Format

Each entry represents a **multi-step moral scenario** based on a central norm (e.g., “It’s unhealthy to overeat”) and consists of 5 sequential steps. Each step presents:

- a situational description,
- a dilemma involving value trade-offs,
- two choices (A and B),
- the associated moral/psychological value each choice expresses (e.g., benevolence, self, conformity),

The data is formatted as a JSON object with the following fields:

### Top-level Fields

| Field Name     | Description |
|----------------|-------------|
| `norm`         | The guiding norm of the scenario (e.g., a health or moral principle) |
| `idx`          | Scenario ID |

### Step-wise Fields

Each scenario includes five decision steps (`step 1` to `step 5`), with the following repeated fields:

| Field Name                     | Description |
|-------------------------------|-------------|
| `step X_situation`            | Description of the social/moral situation |
| `step X_dilemma`              | The moral conflict arising at this step |
| `step X_choiceA`              | Option A presented to the agent |
| `step X_choiceA_value`        | The moral or psychological value associated with Option A (e.g., `benevolence`, `hedonism`, `security`, `conformity`, `self`) |
| `step X_choiceA_value_judgement` | (Optional) Value alignment judgment or label (e.g., `0` for neutral/undecided, `1` for preferred) |
| `step X_choiceB`              | Option B presented to the agent |
| `step X_choiceB_value`        | The value associated with Option B |

> Example values for `value` include: `benevolence`, `conformity`, `self`, `security`, `hedonism`.

